import java.util.*;
class Info
{
	public static void main(String[] args)
	{
		PG pg=new PG();

		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		pg.id=sc.nextByte();
		System.out.println("enter name");
		pg.name=sc.next();
		System.out.println("enter contact");
		pg.contact=sc.nextLong();
		System.out.println("enter address");
		pg.address=sc.next();
		System.out.println("enter email");
		pg.email=sc.next();
		System.out.println("enter weblink");
		pg.weblink=sc.next();
		System.out.println("enter type");
		pg.type=sc.next();

		System.out.println("id: "+pg.id);
		System.out.println("name: "+pg.name);
		System.out.println("contact: "+pg.contact);
		System.out.println("address: "+pg.address);
		System.out.println("email: "+pg.email);
		System.out.println("weblink: "+pg.weblink);
		System.out.println("type: "+pg.type);

		System.out.println(pg.admission(true));
		System.out.println(pg.vacancy(true));
		System.out.println("enter menu veg/non veg");
		String menu=sc.next();
		System.out.println(pg.food(menu));

	}
}







