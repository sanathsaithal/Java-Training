class PG
{
	byte id;
	String name;
	long contact;
	String address;
	String email;
	String weblink;
	String type;

	boolean admission(boolean yes)
	{
		System.out.print("Admission: ");
		return yes;
	}
	String food(String menu)
	{
		System.out.print("you have opted for: ");
		return menu;
	}
	boolean vacancy(boolean yes)
	{
		System.out.print("Vacancy: ");
		return yes;
	}
}
