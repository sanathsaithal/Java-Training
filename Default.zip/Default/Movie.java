class Movie
{
public static void main(String[] args)
{
MovieInfo info= new MovieInfo();
info.information();
}
}