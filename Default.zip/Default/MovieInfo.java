class MovieInfo
{
String name;
int time;
String director;
String type;

MovieInfo()
{

}

void information()
{
System.out.println(name+"\t"+time+"\t"+director+"\t"+type);
}
}