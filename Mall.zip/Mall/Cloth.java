import java.util.*;
class Cloth
{
String gender;
String type;
byte size;
String color;
int price;
int discount;

void getValue()
{
Scanner sc=new Scanner(System.in);
System.out.println("enter gender");
gender=sc.next();
System.out.println("enter type pant/shirt/t-shirt");
type=sc.next();
System.out.println("enter size");
size=sc.nextByte();
System.out.println("enter color");
color=sc.next();
System.out.println("enter price");
price=sc.nextInt();
System.out.println("enter discount");
discount=sc.nextInt();
}

void display()
{
System.out.println("gender: "+gender);
System.out.println("type: "+type);
System.out.println("size: "+size);
System.out.println("color: "+color);
System.out.println("price: "+price);
System.out.println("discount: "+discount);
}
}