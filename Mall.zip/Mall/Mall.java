class Mall
{
public static void main(String args[])
{
Cloth c=new Cloth();
c.getValue();
c.display();

c.gender="male";
c.type="pant";
c.size=38;
c.color="red";
c.price=3;
c.discount=45;

System.out.println("gender: "+c.gender);
System.out.println("type: "+c.type);
System.out.println("size: "+c.size);
System.out.println("color: "+c.color);
System.out.println("price: "+c.price);
System.out.println("discount: "+c.discount);

}
}