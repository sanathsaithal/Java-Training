class PMovie
{
public static void main(String[] args)
{
PMovieInfo info=new PMovieInfo("Zindigi na milegi dobaara",153,"Zoya Akthar","comedy/romance");
info.information();
}
}